﻿namespace Todo
{
	public interface ITextToSpeech
	{
		void Speak(string text);
	}
}

﻿namespace Todo
{
	public interface IFileHelper
	{
		string GetLocalFilePath(string filename);
	}
}
